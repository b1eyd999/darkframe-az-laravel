Color Match v1.3
DaVinci Resolve üçün avtomatik rəng uyğunlaşdırma plugini.
Bu, nümunə/placeholder plugin faylıdır (demo məqsədi ilə).
