Particle FX v2.1
Blender üçün hissəcik (particle) simulyasiya alətləri toplusu.
Bu, nümunə/placeholder plugin faylıdır (demo məqsədi ilə).
