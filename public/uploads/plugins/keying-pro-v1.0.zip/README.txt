Keying Pro v1.0
Adobe After Effects üçün professional green screen (chroma key) plugini.
Bu, nümunə/placeholder plugin faylıdır (demo məqsədi ilə).
